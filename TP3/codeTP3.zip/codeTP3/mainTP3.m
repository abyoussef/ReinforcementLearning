s=simulator; # initializing the simulator 
R=500; #number of restocks
# parameters can be changed WITHIN the simulator object

%% Trying the simulator 

# print the number of drinks of each kind
[s.n_energy,s.n_nosugar]
# perform a transition with no discount
[rew,n_energy,n_nosugar]=s.simulate(0)
# reset the simulator
s.reset();

%% Comparison of one policy with the baseline

V=[0.1,0.2,0.5];
T=[2,5,10];

policy1=@(n1,n2) soda_strategy_discount(n1,n2);
policy2=@(n1,n2) soda_strategy_nodiscount(n1,n2);
%policy3=@(n1,n2) soda_strategy_param(n1,n2,T,V);


%% Choose a bandit problem


TableV=[];
TableT=[];







