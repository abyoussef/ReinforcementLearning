function [ discount ] = soda_strategy_nodiscount( n_energy, n_nosugar)

discount = 0.0;

end

