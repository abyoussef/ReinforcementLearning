classdef EXP3<handle
    % EXP 3 strategy for one player
    
    properties
        nbActions
        eta
        beta
        w 
    end
    
    methods
        
        function self = EXP3(eta,beta,nbActions)
            self.nbActions=nbActions;
            self.eta=eta;
            self.beta=beta;
            self.w=ones(1,self.nbActions);
        end
        
        function self = init(self)
            self.w=ones(1,self.nbActions);
        end
        
        function [action] = play(self)
           % use the weights to choose an action to play
           % TO COMPLETE !
        end
        
        function self = getReward(self,arm,reward)
            % update the weights given the arm drawn and the reward observed
            % TO COMPLETE !
        end
                
    end    
end
