%% Problem specification

% state space
max_height = 5;
S = max_height+1;
sick_state = max_height+1;
init_state = 1;


% action space (a=1 keep; a=2 cut)
A = 2;

% other MDP parameters
gamma = 0.99;
% probability of getting sick
sick_prob = 0.1;
% probability of growing: growth(k,j) is the probability of growing by j when the current height is k
growth=zeros(max_height-1,max_height-1);
growth(1:2,1:3)=1/3;
growth(3,1:2)=1/2;
growth(4,1)=1;
% maintenance and planting cost
maintenance_cost = 1.0;
planting_cost = 1.0;
% price for selling a tree
sell_price=1.0;


% number of trajectories used in MC and TD(0)
runs = 250;
% maximum number of steps per trajectory in MC and TD(0) (this will limit
% the accuracy of the two methods)
max_step = 1000;


%% The MDP
disp('Computing the true MDP...');
[P,R] = tree_MDP(max_height, A, sick_prob, growth,maintenance_cost, planting_cost,sell_price);

%% Definition of an arbitrary policy
pi = zeros(S,1);

% keep
pi(1:3) = 1;
% cut
pi(4:max_height) = 2;
pi(sick_state) = 2;

%% Policy evaluation

%% Optimal policy with DP

%% Optimal policy with RL (Q-Learning)

